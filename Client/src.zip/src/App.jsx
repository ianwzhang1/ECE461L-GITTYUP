import React from 'react';
// import Box from './Box.jsx';
 import Login from './LoginPageComponents/Login.jsx';
import NewBox from './LoginPageComponents/NewBox.jsx';
import SignUpBox from './SignUpPage/SignUpBox.jsx';
import './App.css';   
import Projects from './Projects/Projects.jsx';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';

  // npm install react-router-dom@5 run this to install router

function App() {
  return (
    <Router>
      <div className = 'AppDiv'>
        <Switch>
          <Route exact path="/">
            <NewBox>
            </NewBox>

          </Route>
          <Route exact path="/SignUp">
            <SignUpBox>
            </SignUpBox>
          </Route>
          <Route exact path="/Projects">
            <Projects></Projects>
          </Route>
          
        </Switch>


      </div>
    </Router>

  );
}

export default App;

