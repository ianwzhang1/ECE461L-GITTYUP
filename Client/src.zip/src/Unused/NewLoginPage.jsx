import React from 'react';
import './NewLoginPage.css';

function NewLoginPage(props) {
  return (
    <div>
    </div>
  );
}

export default NewLoginPage;